﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.Design;
using System.Security.Cryptography.X509Certificates;
using static System.Net.Mime.MediaTypeNames;


namespace MyRecipeapp
{
    // Inorder to create an object array (Considered this was easy and less confusing)
    class Step
    {
        //property
        public string mySteps { get; set; }
    }

    // Inorder to create an object array 
    class Ingredient
    {
        // Properties
        public string ingName { get; set; }
        public double ingQuantity { get; set; }
        public string ingUnit { get; set; }
    }

    class Program
    {
        private static double sFactor;
        

        public static void Main(string[] args)
        {
            // Variables to allow user input
            int numIngredients = 0;
            int numSteps = 0;

            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("  RECIPE APP  \n\nNumber of Ingredients? ");
            numIngredients = Convert.ToInt32(Console.ReadLine());
            Ingredient[] ingredients = new Ingredient[numIngredients];
            
            // Allows users to populate the array ingredients
            for (int i = 0; i < numIngredients; i++)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("Ingredient " + (i + 1));
                Console.WriteLine("\nIngredient name: ");
                string ingName = Console.ReadLine();
                Console.WriteLine("\nIngredient quantity: ");
                double ingQuantity = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("\nIngredient unit of measurement: ");
                string ingUnit = Console.ReadLine();
                ingredients[i] = new Ingredient { ingName = ingName, ingQuantity = ingQuantity, ingUnit = ingUnit };
            }
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("\nNumber of steps? ");
            numSteps = Convert.ToInt32(Console.ReadLine());
            Step[] steps = new Step[numSteps];

            // Allows users to populate array steps
            for (int j = 0; j < numSteps; j++)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("Step " + (j + 1));
                Console.WriteLine("Description: ");
                string stepDesc = Console.ReadLine();
                steps[j] = new Step { mySteps = stepDesc };
            }

            // Saves original quantity data
            double[] originalQuantities = new double[numIngredients];

            // Copies data from array ingredients
            for (int i = 0; i < numIngredients; i++)
            {
                originalQuantities[i] = ingredients[i].ingQuantity;
            }

            // Calls methods (You see this throughout the code)
            printIngredients(ingredients);
            printSteps(steps, ingredients, originalQuantities);
            navMenu(ingredients, steps, originalQuantities);
        }

        // Method of a menu to navigate the program
        public static void navMenu(Ingredient[] ingredients, Step[] steps, double[] originalQuantities)
        {
            int ans;
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("  MENU  ");
            Console.WriteLine("1. Display recipe\n2. Scale recipe\n3. Reset scale\n4. New recipe");
            ans = Convert.ToInt32(Console.ReadLine());

            Console.ForegroundColor = ConsoleColor.White;
            // User selects options through 1 - 4 
            if (ans == 1)
            {
                 printIngredients(ingredients);
                 printSteps(steps, ingredients, originalQuantities);
            }
            else if (ans == 2)
            {
                scale(ingredients, steps, originalQuantities);
            }
            else if (ans == 3)
            {
                ogRecipe(ingredients, steps, originalQuantities);
            }
            else if (ans == 4)
            {
                newRecipe(ingredients, steps, originalQuantities);
            }
            else
            {
                Console.WriteLine("Please choose one listed on the menu");
                navMenu(ingredients, steps, originalQuantities);
            }
        }

        // Method to output array ingredients
        public static void printIngredients(Ingredient[] ingredients)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n---------------------------------\nIngredients:");
            for (int i = 0; i < ingredients.Length; i++)
            {
                Console.WriteLine($"  - {ingredients[i].ingName}: {ingredients[i].ingQuantity} {ingredients[i].ingUnit}");
            }
        }

        // Method to output array steps
        public static void printSteps(Step[] steps, Ingredient[] ingredients, double[] originalQuantities)
        {
            Console.WriteLine("\nSteps:");
            for (int i = 0; i < steps.Length; i++)
            {
                Console.WriteLine($"  {i + 1}. {steps[i].mySteps}");
            }
            Console.WriteLine("\n---------------------------------");
            navMenu(ingredients, steps, originalQuantities);
        }

        // Method to scale the ingredient quantity by a certain factor
        public static void scale(Ingredient[] ingredients, Step[] steps, double[] originalQuantities)
        {

            double sFactor;
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("\n  Scale  \nScale recipe by 0.5(half), 2(double) or 3(triple)?");
            sFactor = Convert.ToDouble(Console.ReadLine());

            // Scale is made by multiplying quantity and factor 
            Console.ForegroundColor = ConsoleColor.White;
            if (sFactor == 0.5)
            {
                // Multiplying by 0.5
                foreach (var ingredient in ingredients)
                {
                    ingredient.ingQuantity *= sFactor;
                }
                
                printIngredients(ingredients);
                printSteps(steps, ingredients, originalQuantities);
                navMenu(ingredients, steps, originalQuantities);
            }
            else if (sFactor == 2)
            {
                // Multiplying by 2
                foreach (var ingredient in ingredients)
                {
                    ingredient.ingQuantity *= sFactor;
                }
                
                printIngredients(ingredients);
                printSteps(steps, ingredients, originalQuantities);
                navMenu(ingredients, steps, originalQuantities);

            }
            else if (sFactor == 3)
            {
                // Multiplying by 3
                foreach (var ingredient in ingredients)
                {
                    ingredient.ingQuantity *= sFactor;
                }
                
                printIngredients(ingredients);
                printSteps(steps, ingredients, originalQuantities);
                navMenu(ingredients, steps, originalQuantities);

            }
            else {

                Console.WriteLine("You didn't select any of the scaling options...");
                scale(ingredients, steps, originalQuantities);
            }

        }

        // Method to reset scaled values to original
        public static void ogRecipe(Ingredient[] ingredients, Step[] steps, double[] originalQuantities)
        {

            // Choice to reset the values
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("\n  Reset values  \nReset recipe to original values? y/n");
            char ans = Convert.ToChar(Console.ReadLine());
            if (ans == 'y') {

                Console.ForegroundColor = ConsoleColor.White;
                // Resets values to original by aquiring them from array originalQuantities
                for (int i = 0; i < ingredients.Length; i++)
                {
                    ingredients[i].ingQuantity = originalQuantities[i];
                }

                printIngredients(ingredients);
                printSteps(steps, ingredients, originalQuantities);
                navMenu(ingredients, steps, originalQuantities);

            }
            else if (ans == 'n') {

                printIngredients(ingredients);
                printSteps(steps, ingredients, originalQuantities);
                navMenu(ingredients, steps, originalQuantities);
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Please choose either y or n");
                ogRecipe(ingredients, steps, originalQuantities);
            }
        }
        
        // Method for a new recipe
        public static void newRecipe(Ingredient[] ingredients, Step[] steps, double[] originalQuantities)
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("\nAre you sure you want to clear recipe?  y/n");
            char ansb = Convert.ToChar(Console.ReadLine());

            Console.ForegroundColor = ConsoleColor.White;
            if (ansb == 'y')
            {

                // Clears the ingredients array
                Array.Clear(ingredients, 0, ingredients.Length);

                // Clears the steps array
                Array.Clear(steps, 0, steps.Length);

                // Calls the Main method to restart the program
                Main(new string[] { });
            }
            else if (ansb == 'n')
            {

                navMenu(ingredients, steps, originalQuantities);
            }
            else {

                Console.WriteLine("Please choose either y or n");
                newRecipe(ingredients, steps, originalQuantities);
            }
        }
    }
}
